# Access Request-Android

## Set Up Dev Environment 
1. **Admin Rights:** Ensure you have Admin rights before starting. The setup may take half a day, and you'll receive an email once complete. Avoid using outdated software from Self Service.  

2. **Wi-Fi Connection:** Connect to "Target Guest Wi-Fi" instead of "HQwireless" to avoid firewall issues during installation.  

3. **[Android Studio](https://developer.android.com/studio/):**  
   - Download the latest stable version from the internet (not Target Managed Software Center).  
   - Check AGP compatibility before downloading.  
   - Allocate at least 8192 MiB of memory via Help > Change Memory Settings for better performance.  

4. **[Homebrew](https://brew.sh):** Install Homebrew or another package manager of your choice for managing packages.  

5. **Git Setup:**  
   - Install Git using `brew install git`.  
   - Enable bash completion with `brew install bash-completion`.  
   - Configure your `user.name` and `user.email` using these [Git commands](https://docs.github.com/en/account-and-profile/setting-up-and-managing-your-personal-account-on-github/managing-email-preferences/setting-your-commit-email-address).  
   - Update your username to "FirstnameLastname" using the `octobot` command.  

6. **SSH Keys:** Add an SSH key to your GitHub account and configure it with ssh-agent for passwordless authentication. Use the key [setup guide](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/adding-a-new-ssh-key-to-your-github-account) for assistance.  

7. **GitHub Account:** If your account is locked, unlock it using the octobot `unlock <your zID>` command.  

8. **Pulling Code:** Refer to the [Branching Strategy](https://pages.git.target.com/mobile-apps/guide/docs/getting-started/branching-strategy/) guide. Always fork the repository instead of directly cloning it.

## Octobot

Octobot is a tool that will help you manage your Github account directly from Slack.

Octobot commands can be executed in two ways:
- In the slack channel #github-enterprise, send the message @octobot <octobot command>.
- Send a DM to @octobot with the command directly.

By default, GitHub displays your Target zID; use the `octobot` command (`username <firstlast>`) in a Slack PM to @octobot (e.g., `username matiasduarte`) to update it.

## JDK
Use [SDKMAN!](https://gyde.prod.target.com/gydelines/jdk-management-and-usage?step=3) to manage JDK versions; run `sdk env install` in the project root or install the specified JDK manually, ensuring the same JDK is used for Android Studio and the command line to avoid inconsistencies.

**Environmental Variable**

After installing a JDK via SDKMAN!, start a new shell and run `echo $JAVA_HOME` to confirm it outputs the correct JDK path.

**Android Studio JDK**

Once JAVA_HOME is set, configure Android Studio to use same JDK.

## Flipper

Flipper is a debugging platform with tools like SQLite inspectors, shared preferences, and network call analysis. Download and install the desktop app directly, as it’s not available in the Managed Software Center.
1. Download the latest `.tgz` release of custom Flipper plugins for internal tools like Firefly from the `flipper-desktop-plugins` repo.  
2. Open Flipper, go to "Manage Plugins," select "Install Plugins," and drag and drop the `.tgz` file.  
3. For unverified `.dmg` packages, use **Ctrl+Click > Open** to bypass Apple’s security restriction (review the official doc for risks).  
4. Use Flipper to mock APIs; refer to the [codelab](https://pages.git.target.com/mobile-apps/Codelabs/html/mock-api-using-flipper/#0) (VPN required) for setup and installation instructions.

## Github Copilot
Currently Github Copilot is the only supported code companion that can be used.

1. Follow the guide for getting started with [Copilot](https://pages.git.target.com/github/doc-site/copilot/).
- You must complete the training and steps listed in that guide.
- Use MyAccess to request the `APP-GHE-Copilot` entitlement to be able to use this tool (manager approval required).
- Once the entitlement is granted, you will be added to Copilot org in Github (this happens on the Friday after it is granted), confirm you are authorized using the [go/github-copilot-auth](https://github.com/enterprises/target-emu/sso) link.
  
2. Use the installation instructions from that guide to configure Android Studio.
- The doc points to the InteliJ install guide which explains how to locate and install the plugin.

  i) If prompted, don't change the Authorization Server - because we authenticate using the default one.
  
- Login to Github when prompted by the Android Studio Copilot Plugin.
  
Slack channel for questions: `#coding-companion-community`

## Develocity (formerly known as Gradle Enterprise)

Develocity is a paid tool with a limited number of seats. To ensure compliance within the license terms all users must receive entitlements through MyAccess and authenticate in our [Develocity Portal](https://fgelx1003.hq.target.com/scans?search.timeZoneId=Asia%2FCalcutta)

- Request `APP-GET-Read-Prod` entitlement in MyAccess (requires manager and Brian Winters' approval). 
- Run `./gradlew provisionDevelocityAccessKey` in Android Studio or terminal to generate a provisioning link.
- Open the link in a browser and sign in using Target SSO to complete access key provisioning. 
- If access is denied, confirm entitlement approval or check [Gradle's Automated Access Key Provisioning](https://docs.gradle.com/develocity/gradle-plugin/current/#automated_access_key_provisioning) doc; reach out in `#mobile-platform` for help.

## Get Access

Below is the list of most of the Request Access required for a Mobile Developer - Android
1. `APP-FF-Kibana-Read-Prod-Requestable` - To access prod kibana logs
2. `Axiom - User - Non-Prod : APP-Axiom-User-NP (Active Directory)`
3. `Axiom - User - Prod : APP-Axiom-User (Active Directory)` - To access axiom for multiple reasons post purchase etc. Prod and Stage
4. `Bugsnag - View - Prod : APP-Bugsnag-View (ActiveDirectory)`- To access bugsnag - Flagship iOS and Android app error logs (unhandled / handled errors)
5. `Bullflight - Read - Prod : APP-OAUTH2-BUL-Read-Prod (ActiveDirectory)`
6. `Confluence - User - Prod : APP-CONFLUENCE-USER (Active Directory)`- Confluence request
7. `Zoom Meetings (Zoom) - Operator - Prod` : APP-Zoom-Record (ActiveDirectory)- Enables record option in zoom meetings
8. `Firefly Kibana (FFK) - General Analytics - Prod : APP-FFK-GeneralAnalytics (Active Directory)`- Firefly Kibana access - to access analytics logs
9. `GitHub Enterprise - User : APP-GHE-WRITE (Active Directory)` - github access
10. `Guest Order Management (GOM) - GOM Console UI Read-Only - Non-Prod : APP-OAUTH2-GOMUI-READ-NPE (Active Directory)`- Post Purchase - To update order state
11. `Jira - User - Prod : APP-JIRA-USER (Active Directory)`- Jira access
12. `Miro (MIR) - View - Prod : APP-MIR-BaseAccess (ActiveDirectory)`
13. `Miro (MIR) - Write - Prod : APP-MIR-FullMembers (ActiveDirectory)`- Read / Write access for Miro - usually teams collaborate
14. `Portable Media (USB) - USB Port - PC or Laptop : APP-USB-1Year-ReadWrite (Active Directory)`- To access USB ports, required for connecting iPhone / Android for debugging purpose
15. `Sapphire - Create Tests - Prod : APP-Sapp-Create (Active Directory)`
16. `Sapphire - View All Tests - Prod : APP-Sapp-View (Active Directory)`- Sapphire access - Target internal feature release strategy
17. `ServiceNow - TTS ITIL - User`- Incident management access
18. [Github](https://git.target.com/mobile-apps): which is already done since you're reading this.
19. [Slack](https://target.enterprise.slack.com/signin/find-workspaces), our primary chat app.
20. [Confluence](https://confluence.target.com/pages/viewpage.action?spaceKey=APPS&title=Apps+Home), for document storage.
 - This Confluence space contains documentation primarily intended for communication with Target partners, including product, design, and other engineering teams.
 - [go/mobile-apps](https://pages.git.target.com/mobile-apps/guide/) contains our engineer onboarding guide, internal docs for on-call, and more.
 - The Android team also maintains [technical documentation](https://pages.git.target.com/mobile-apps/flagship-android/) specific to our codebase.
21. [Jira](https://jira.target.com/secure/Dashboard.jspa), our issue tracker.
22. [BugSnag](https://app.bugsnag.com/user/sign_in), our crash reporting tool.
23. Firebase, another metrics and crash reporting tool - Request `Google Cloud Platform(GCP) - APP-TGT-FLAGSHIP-FIREBASE` in [MyAccess](https://myaccess.prod.target.com)
24. Outlook distribution lists: TD-Apps & specific relevant sub-teams e.g. TD-Apps-Checkout
25. `APP-TGT-MOBILEPOS-FIREBASE`  - Access to firebase test labs
26. `Figma - Write - Prod : APP-FIGMA-DEV-MODE (ActiveDirectory)` - Access to Figma Dev Mode
27. `GRADLE ENTERPRISE TARGET ANDROID - Read - Prod : APP-GET-Read-Prod (ActiveDirectory) ` - Provides Read access to GRADLE ENTERPRISE TARGET ANDROID for Android - Platform/Design Systems
28. `Thalamus (THL) - Data Analyst - Prod : APP-THL-DataAnalyst (Active Directory)`  - Provides Read, Write access to Thalamus for EDABI High Performance Computing Team

Once all the access requests are being processed, take some time to view the [TTS First Day Wiki page](https://wiki.target.com/tgtwiki/index.php/Target_tech_Day_One_Technology_Resources). It is essentially a much more comprehensive version of general onboarding and resources.
## References
 - https://wiki.target.com/tgtwiki/index.php/Slack
 - https://wiki.target.com/tgtwiki/index.php/Confluence
 - https://wiki.target.com/tgtwiki/index.php/JIRA
   
