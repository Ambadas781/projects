# Access Request Web
## Local Admin Rights(LAR)

**Test for Local Admin Rights (LAR):**  
1. Open Terminal, run: `sudo ls`, and enter your password.  
   - If it fails, proceed to gain access.  
2. **Check & Install LAR:**  
   - Open Managed Software Center: `Finder > Applications > Managed Software Center`.  
   - Search `Local Admin Rights`, select `Install`.  
   - Restart if prompted.  
3. **Request LAR (if needed):**  
   - Go to [MyAccess](https://go/myaccess), request `ADMN-Wrkstn-LAR-1Year`  
   - Once granted, a **Notification Center prompt** will confirm access.

## My Access
Target provides default permissions for basic engineering tasks, but full access may take time. Use [MyAccess](https://go/myaccess) to manage permissions—follow the steps below to streamline setup.
1. Find someone on your team that already has the correct access permissions (or talk to your SEM) (HINT: your mentor or someone with the same title as you is a good place to start)
2. Search for that person in MyAccess
3. Click the Compare User Access button from their profile to get an idea for some of the permissions you might need to request. Select All (or the permissions you need).
4. Request the permissions
Your designated manager (or SEM) will need to approve your request before you can start leveraging that access.

## Team & Developer Workflow
Target Web leverages a few tools for workflow management.
1. [Jira](https://jira.target.com) - is the day-to-day workflow dashboard used for tracking and collaboration of team work. Your team leader and/or Scrummaster will direct you to the specific dashboard for your team.

2. [Confluence](https://confluence.target.com) - is Target's web-based collaboration wiki used for documentation and collaboration.d out who is on which teams on the [Digital Web Engineering Structure](https://confluence.target.com/pages/viewpage.action?spaceKey=DIG&title=2024+Digital+Engineering+Structure) Confluence page.

3. [Github Projects](https://docs.github.com/en/issues/planning-and-tracking-with-projects/learning-about-projects/about-projects)- some teams use this tool as keeps the work closer to the process workflow.

## Enterprise Chatbots

![image](https://git.target.com/Z00FB1J/Access-Request-Web/assets/25997/fdb739a2-a3ac-46d5-b8c6-193d79198da4)

1. **Pull Remainders** - Pull Reminders is a Slack bot that helps developers review and merge pull requests faster with real-time notifications.
   **Setup**
   - Under the "Apps" section in Slack search for and add the "Pull Reminders" App.
   - Visit https://pullreminders.prod.target.com/installs/ to add the desired organizations.
   - You can update your notifcation settings by clicking on "My DM settings" from the main "getting started" page for a specific organization.
2. **Outlook Calender** - OutlookCalendar is a Slack bot that integrates your Outlook calendar, keeping your team informed and your schedule accessible. It syncs your calendar with Slack status, provides daily schedule views, and sends meeting reminders. You can create events, RSVP, and join meetings directly from Slack.
3. **Calo** - [Calo](https://wiki.target.com/tgtwiki/index.php/Calo) is an AI-powered personal assistant for Target India team members, providing information on learning, transport, HR policies, IT helpdesk, building operations, events, and more. It is evolving to offer personalized insights and perform actions on behalf of users. Available on **Slack** (search "Calo" in Apps) and **Web App** (Calo Web Application).
   
## GitHub 

1. Ensure you are a member of the `APP-GHE-WRITE` AD group. This can be done by using `@octobot entitlement your-LAN-ID` in Slack.
2. Login to your GitHub.com profile at github.com/login.
3. In order to use SSH keys or personal access tokens with those organizations, you'll need to authorize them individually. You can do this by using the following guides for the SAML protected organization:
   - [GitHub](https://docs.github.com/en/enterprise-cloud@latest/authentication/authenticating-with-saml-single-sign-on/authorizing-an-ssh-key-for-use-with-saml-single-sign-on): Authorizing an SSH key for use with SAML single sign-onopens in a new window
   - [GitHub](https://docs.github.com/en/enterprise-cloud@latest/authentication/authenticating-with-saml-single-sign-on/authorizing-a-personal-access-token-for-use-with-saml-single-sign-on): Authorizing a personal access token for use with SAML single sign-on
4. Approved Technoligies - https://git.target.com/targettech/approved_technologies


## Request Access Required for Web
1. `APP-FF-Kibana-Read-Prod-Requestable` - To access prod kibana logs
2. `Grafana - User - Prod: APP-Metricsdata-IPSF (Active Directory)` - for seeing api related metrics via otel data.
3. `Grafana - User - Non-Prod : APP-Metricsdata-IPSF (Active Directory)` - - for seeing api related metrics via otel data.
4. `Firefly Kibana (FFK) - General Analytics - Prod : APP-FFK-GeneralAnalytics (Active Directory)` - this is for seeing logs for click tracking data
5. `ServiceNow - TTS ITIL - User` - or incident management
6. `Figma - Write - Prod : APP-FIGMA-DEV-MODE` - for figma design tool dev mode access
7. axiom user access
   i. non prod access : `Axiom - User - Non-Prod : APP-Axiom-User-NP (Active Directory)`
   ii. prod access : `Axiom - User - Prod : APP-Axiom-User`
8. Access : `Sapphire - Create Tests - Prod : APP-Sapp-Create (Active Directory)` - sapphire is used to create AB tests.
9. Developer Portal Access - All Target team members can access the Developer Portal using their Target lan id and password. External third party developers will need to be invited by a Target team member. Invites can be generated on the [invitations](https://developer.target.com/invitations) page.

## Slack Channels
1. [#web-enablement](https://target.enterprise.slack.com/archives/C01TKHP0AJU) - Web Enablement is made up of 3 teams that enable front-end development experiences (Teams: Platform, Nicollet (Design Systems), CIA (Infra and Deployment))
2. #digital-web
3. #digital-incidents
4. #web-ui-engineers
5. #web-site-releases
6. #web-engineering-bytes - monthly learning and demo segment run by Digital Web engineers
7. #web-platform-community
8. #web-platform-community-prs

## References
Workstation Setup - https://learninghub.prod.target.com/docs/awesome-engineer-onboarding/01-day-one#windows-users

https://wiki.target.com/tgtwiki/index.php/Portal:Mac/Software/Request_LAR
