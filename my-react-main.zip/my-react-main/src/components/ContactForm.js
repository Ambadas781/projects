import React from 'react';
import axios from 'axios';
import useForm from '../hooks/useForm';

function ContactForm() {
  const { values, handleChange, resetForm } = useForm({
    name: '',
    email: '',
    message: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post('/contact', values);
      alert('Thanks for reaching out!');
      resetForm();
    } catch (error) {
      alert(error.response?.data?.message || 'Failed to send your message.');
    }
  };

  return (
    <section className="contact">
      <h2>Contact Me</h2>
      <form onSubmit={handleSubmit}>
        <input
          name="name"
          value={values.name}
          onChange={handleChange}
          placeholder="Name"
        />
        <input
          name="email"
          value={values.email}
          onChange={handleChange}
          placeholder="Email"
        />
        <textarea
          name="message"
          value={values.message}
          onChange={handleChange}
          placeholder="Message"
        />
        <button type="submit">Send</button>
      </form>
    </section>
  );
}

export default ContactForm;
