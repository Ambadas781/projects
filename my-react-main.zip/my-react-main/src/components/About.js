import React, { useState } from 'react';

function About() {

  const [showMore, setShowMore] = useState(false);

  const toggleShowMore = () => setShowMore((prev) => !prev);

  return (
    <section className="about">
      <h2>About Me</h2>
      
      <p>
        Hi, I'm a software engineer passionate about building user-friendly websites.{' '}
        {showMore && 'I specialize in HTML,CSS,React.js, JavaScript, and web performance optimization.'}
      </p>
      <button onClick={toggleShowMore}>{showMore ? 'Show Less' : 'Show More'}</button>
    </section>
  );
}

export default About;
