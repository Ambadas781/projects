import React, { useEffect, useState } from 'react';
import ProjectCard from './ProjectCard';
import { fetchProjects } from '../api/projectsApi';

function Projects() {
  const [projects, setProjects] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadProjects = async () => {
      try {
        const data = await fetchProjects();
        setProjects(data);
      } catch (err) {
        setError(err.message || 'Failed to load projects.');
      }
    };

    loadProjects();
  }, []);

  if (error) {
    return <p className="error-message">{error}</p>;
  }

  return (
    <section className="projects">
      <h2>My Projects</h2>
      <div className="project-list">
        {projects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </section>
  );
}

export default Projects;
