import React, { useState } from 'react';

function ProjectCard({ project, onUpdateTitle }) {
  const [newTitle, setNewTitle] = useState('');

  const handleChange = (e) => setNewTitle(e.target.value);
  const handleUpdate = () => onUpdateTitle(project.id, newTitle);

  return (
    <div className="card">
      <h3>{project.title}</h3>
      <p>{project.description}</p>
      <input type="text" value={newTitle} onChange={handleChange} placeholder="Update Title" />
      <button onClick={handleUpdate}>Update Title</button>
    </div>
  );
}

export default ProjectCard;
