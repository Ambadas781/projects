import React from 'react';

function Footer() {
  return (
    <footer style={styles.footer}>
      <p>&copy; {new Date().getFullYear()} Vinayak Y Bajantri. All rights reserved.</p>
      <p>
        Built with <span style={{ color: 'red' }}>❤</span> using React.
      </p>
      <ul style={styles.socialLinks}>
        <li><a href="https://github.com/your-username" target="_blank" rel="noopener noreferrer">GitHub</a></li>
        <li><a href="https://linkedin.com/in/your-username" target="_blank" rel="noopener noreferrer">LinkedIn</a></li>
        <li><a href="https://twitter.com/your-username" target="_blank" rel="noopener noreferrer">Twitter</a></li>
      </ul>
    </footer>
  );
}

const styles = {
  footer: {
    textAlign: 'center',
    padding: '20px',
    background: '#222',
    color: '#fff',
    marginTop: '30px',
  },
  socialLinks: {
    listStyle: 'none',
    display: 'flex',
    justifyContent: 'center',
    padding: 0,
    margin: '10px 0',
  },
  link: {
    margin: '0 10px',
    color: '#fff',
    textDecoration: 'none',
  },
};

export default Footer;
