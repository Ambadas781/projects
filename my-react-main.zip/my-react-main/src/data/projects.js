const projectsData = [
    { id: 1, title: 'Thyroid Cancer Detection System', description: 'It detects the stages of thyroid cancer and provide the guidance.in this we used KNN Algorithm,Random Forest etc' },
    { id: 2, title: 'Online Exam Application Portal', description: 'An online exam application for students to dircetly apply in the website have and access through all the links.' },
    { id: 3, title: 'Skypass', description: 'A Movie ticket booking app with all the remainders of the tickets and coupons' },
  ];
  
  export default projectsData;
  