import apiClient from './apiClient';

export const fetchProjects = async () => {
  try {
    const response = await apiClient.get('/posts');
    return response.data; // Assuming the API returns a list of projects
  } catch (error) {
    console.error('Error fetching projects:', error.message);
    throw error;
  }
};
