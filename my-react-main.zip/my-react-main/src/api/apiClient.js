import axios from 'axios';

const apiClient = axios.create({
    baseURL: 'https://jsonplaceholder.typicode.com',
    timeout: 5000,
  });
  

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    let message = 'An error occurred.';
    if (status === 404) message = 'Resource not found.';
    if (status === 500) message = 'Server error. Please try again later.';
    return Promise.reject({ ...error, message });
  }
);

export default apiClient;
