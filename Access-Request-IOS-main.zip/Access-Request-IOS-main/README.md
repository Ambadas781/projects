# Access Request-IOS

## Mobile Platform Onboarding

On your first day, introduce yourself as a new Flagship iOS developer in the `#mobile-platform` Slack channel. Members of the platform team can get you setup with:

- Your Apple Developer account
- Anything else you may have trouble with
  
## Apple Developer

To be able to download Xcode and generate and use a development provisioning profile, you'll need to be added to the App Store developer account.

You will have to make an Apple ID using your Target email address if you haven't created one with Target already.

![Note] your Target SSO credentials are not synced with your Apple Developer account password. Make sure you remember it!

![image](https://git.target.com/Z00FB1J/Access-Request-IOS/assets/25997/06a18454-b530-4525-9f17-34036797785d)

Once your Apple Developer account is setup, you'll need to setup your developer certificate:

1. Open up Xcode
2. Navigate to Xcode (in the global menu) > Settings > Accounts
3. Login to your Apple ID if you haven't already
4. Click on `Managed Certificates`...
5. In the opened popup window, click on the plus button and select `Apple Development`
6. You should see your generated certificate like so
7. Click done and exit out of settings
   
## Flagship iOS Email Distribution

The official email list for iOS developers is `TTS-Flagship-iOS-Devs@target.com`. This distribution list is used for invites for all iOS developer meetings.

## Registering Your Test Device

You can register your device by entering the UDID at https://bullflight.target.com/register-device.

![image](https://git.target.com/Z00FB1J/Access-Request-IOS/assets/25997/0dc2199c-48c7-42a3-bf50-b1a56b35ce62)

To find your device's UDID:

1. Connect your device to your computer
2. Accept any trust prompts on your computer and phone
3. The phone will appear under Locations in the finder's side bar
4. Select your phone to see its information
5. Click the area under your phone's name a few times until you see its UDID
6. Right-click the UDID and choose Copy UDID Developer certificate installed

## Things to Know

Below is a brief list of important tools, technologies general things-to-know.
- **System Dependencies**: Tools like build tools, linters, and analyzers used during development but not shipped with the software.  
- **Homebrew**: A package manager for macOS programs, primarily pre-built binaries.  
- **Just**: A command runner for project-specific tasks (e.g., installing Xcode, running Tuist).  
- **Tuist**: A tool for defining Xcode projects with features like dynamic generation, test hashing, and dependency graph validation using Swift.  
- **SwiftLint**: A linter to enforce consistent Swift code style, integrated into PRs and local builds.  
- **Ruby/RubyGems**: Ruby-based tools (e.g., Fastlane, Danger) are installed and managed as RubyGems.  
- **Bundler**: A RubyGem package manager used to run Fastlane and manage dependencies like Carthage.  

For a full information of tools and dependencies, check out the [dependencies](https://pages.git.target.com/mobile-apps/guide/docs/flagship-ios/dependency-management) page.

## BullFlight

BullFlight is used by the apps teams at Target to distribute test builds. It is very similar to the products provided by HockeyApp, Fabric, Microsoft App Center, (or TestFlight before they were bought by Apple).

BullFlight is open to all Target team members, and protected by SSO. Additionally, all BullFlight builds are Ad-Hoc or Developer signed and can only be installed on known devices previously registered.

- **BullFlight Web**: Access BullFlight at [bullflight.target.com](https://bullflight.target.com) to download apps and register devices.  
- **BullFlight iOS**: Download iOS builds from [bullflight.target.com/build/bullflight/ios](https://bullflight.target.com/build/bullflight/ios) for BullFlight functionality in one app.  
- **BullFlight macOS**: A macOS client for browsing and installing iOS simulator builds, available via Managed Software Center.  

### Prerequisites

- Read access is required to download BullFlight. You should have access already via the APP-Digital-FlagshipDeveloper-Requestable role, but if not please head on over to [go/MyAccess](https://myaccess.prod.target.com) and request access to entitlement APP-OAUTH2-BUL-Read-Prod.
- It is recommended to register your personal device if you want to be able to scan and download the builds in BullFlight to your personal device.
- Xcode is required for BullFlight to successfully fetch and utilize the iOS Simulators that come bundled with Xcode for testing. Users outside of the development space can use the following guide or go to the Getting Started page to learn more about the process our developers follow which involves cloning the main repo.
- Local Admin Rights will allow for Xcode Installation, available on the Managed Software Center or [go/MyAccess](https://myaccess.prod.target.com).

### How to install Xcode

Once Xcode is installed, the dropdown menu within BullFlight will become available and provide you with a selection of iOS Simulators. The QR Codes above the dropdown will provide a link to your registered device.

**MDM Installation**

- Visit go/MyAccess and request for the following entitlement: app-macOS-xcode
- Once approved, wait for the Xcode installation prompt to appear. This can take about a day.
- Ensure the iOS and macOS runtimes are selected for download and installation on the prompt and proceed.
  
## Danger

Danger is a tool we use to encourage and enforce healthy PRs. You may notice "FlagshipBot" giving your PRs a slight nudge to conform to some rules we've written.

If you've fixed the warnings and errors, you can simply leave this comment on your PR to tell the build farm to re-check:

`danger me`

## Loganbot

Loganbot is a Slackbot that automates many of our team processes such as TestFlight builds. You can learn more about Loganbot on its Github page:

https://git.target.com/mobile-apps/loganbot

## Tempo

Tempo is a Flux-inspired framework developed by Target mobile developers with the goals of:

- Develop UIs using unidirectional dataflow.
- Help the separation of UIKit MVC elements (UIViewController, UIView) from business and presentation logic.
- Make the creation of dynamic, vertically scrolling, UICollectionView-backed UIs easy and repeatable - powering most of our features and design language.
  
Tempo is both easy to get started with but difficult to master. For now, the best way to learn is to work with a lead engineer and reference examples from existing features - combined with practices and patterns from the article posted above.

## Slack

There are many team-specific channels depending on what group you are a member of. For all iOS developers, it is important to join:

`#flagship-ios` - General Flagship iOS app discussion

`🔒flagship-ios-devs` - Flagship iOS developers and code discussions

`#ios-release-train` - Active discussion and announcements for app releases

`#mobile-platform` - General Platform support (e.g. Apple developer account issues, build issues, CI/CD, etc.)

`#flagship-app-reviews-ios` - A feed of reviews for our app from the App Store

`#bullflight-apps-builds` is the slack channel that reports new BullFlight iOS and macOS builds.
